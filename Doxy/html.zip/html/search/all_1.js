var searchData=
[
  ['datiatleta_0',['DatiAtleta',['../struct_dati_atleta.html',1,'']]]
];
