var searchData=
[
  ['salvataggio_0',['Salvataggio',['../_coordinate_8cpp.html#aaf746b1ca6a12c6a2ddcca900de34fd1',1,'Coordinate.cpp']]]
];
