var searchData=
[
  ['inseriscidati_0',['InserisciDati',['../_coordinate_8cpp.html#a95c656494b845caeb7fbe24b4e807e98',1,'Coordinate.cpp']]]
];
