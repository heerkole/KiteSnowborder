var searchData=
[
  ['readme_0',['README',['../md__c___users_frane__one_drive__documenti__scuola__programmazione__c___4_xC2_xB0__anno__febbraio15d65e6fdf312a646ede6ea9fade2bb7.html',1,'']]]
];
