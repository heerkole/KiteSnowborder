var indexSectionsWithContent =
{
  0: "cdgimrsv",
  1: "d",
  2: "c",
  3: "cgimsv",
  4: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "pages"
};

var indexSectionLabels =
{
  0: "Tutto",
  1: "Classi",
  2: "File",
  3: "Funzioni",
  4: "Pagine"
};

