var searchData=
[
  ['calcolapodio_0',['CalcolaPodio',['../_coordinate_8cpp.html#a3d3e37ac9a6a76af820be3cf2a854b14',1,'Coordinate.cpp']]],
  ['coordinate_2ecpp_1',['Coordinate.cpp',['../_coordinate_8cpp.html',1,'']]]
];
